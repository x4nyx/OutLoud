USE OutLoud;

CREATE TABLE groupst(
	id INT NOT NULL AUTO_INCREMENT,
	description TEXT NULL,
	userNum INT NULL,
	name VARCHAR(30) NULL,
	confirmation INT NULL,
	creatorid INT NULL,
	PRIMARY KEY (id)
)