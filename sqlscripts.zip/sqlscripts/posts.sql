USE OutLoud;

CREATE TABLE posts (
    id int NOT NULL AUTO_INCREMENT,
    creatorid int NULL,
    text text NULL,
    groupid int NULL,
    title text NULL,
    viewCount int NULL,
    PRIMARY KEY (id)
);
