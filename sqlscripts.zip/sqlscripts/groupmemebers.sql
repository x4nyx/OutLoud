USE OutLoud;

CREATE TABLE groupmembers(
	groupid INT NULL,
	userid INT NULL
)