CREATE DATABASE OutLoud;

USE OutLoud;

CREATE TABLE albums(
	id INT NOT NULL AUTO_INCREMENT,
	name VARCHAR(30) NULL,
	isPlaylist INT NULL,
	creationDate DATE NULL,
	creatorid INT NULL,
	PRIMARY KEY (id)
);

CREATE TABLE genres(
	id INT NOT NULL AUTO_INCREMENT,
	name VARCHAR(30) NULL,
	PRIMARY KEY (id)
);

CREATE TABLE groupmembers(
	groupid INT NULL,
	userid INT NULL
);

CREATE TABLE groupst(
	id INT NOT NULL AUTO_INCREMENT,
	description TEXT NULL,
	userNum INT NULL,
	name VARCHAR(30) NULL,
	confirmation INT NULL,
	creatorid INT NULL,
	PRIMARY KEY (id)
)

CREATE TABLE posts (
    id int NOT NULL AUTO_INCREMENT,
    creatorid int NULL,
    text text NULL,
    groupid int NULL,
    title text NULL,
    viewCount int NULL,
    PRIMARY KEY (id)
);

CREATE TABLE reports (
    id int NOT NULL AUTO_INCREMENT,
    creatorid int NULL,
    status nchar(20) NULL,
    text text NULL,
    helperid int NULL,
    title text NULL,
    PRIMARY KEY (id)
);

CREATE TABLE tracklist (
	albumid INT NULL,
	trackid INT NULL
);

CREATE TABLE tracks(
	id int NOT NULL AUTO_INCREMENT,
	playsCount int NULL,
	date date NULL,
	name nchar(30) NULL,
	creatorid int NULL,
	genreid int NULL,
	PRIMARY KEY (id)
);

CREATE TABLE users (
	id int NOT NULL AUTO_INCREMENT,
	name varchar(30) DEFAULT NULL,
	confirmation INT(1) DEFAULT NULL,
	login varchar(30) DEFAULT NULL,
	password varchar(24) DEFAULT NULL,
	role varchar(24) DEFAULT NULL,
	PRIMARY KEY (id)
);