USE OutLoud;

CREATE TABLE albums(
	id INT NOT NULL AUTO_INCREMENT,
	name VARCHAR(30) NULL,
	isPlaylist INT NULL,
	creationDate DATE NULL,
	creatorid INT NULL,
	PRIMARY KEY (id)
) 
