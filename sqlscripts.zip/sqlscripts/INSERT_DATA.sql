USE OutLoud;

INSERT INTO albums (name, isPlaylist, creationDate, creatorid)
VALUES ('First', '0', DATE '2020-12-17', 1);
INSERT INTO albums (name, isPlaylist, creationDate, creatorid)
VALUES ('First', '1', DATE '2020-12-20', 2);

INSERT INTO genres (name)
VALUES ('Shanson');
INSERT INTO genres (name)
VALUES ('RocknRoll');
INSERT INTO genres (name)
VALUES ('Undefined');

INSERT INTO groupmembers (groupid, userid)
VALUES ('1', '1');
INSERT INTO groupmembers (groupid, userid)
VALUES ('1', '2');
INSERT INTO groupmembers (groupid, userid)
VALUES ('2', '2');
INSERT INTO groupmembers (groupid, userid)
VALUES ('2', '3');

INSERT INTO groupst (description, userNum, name, confirmation, creatorid)
VALUES ('nothing', '2', 'First', '1', '1');
INSERT INTO groupst (description, userNum, name, confirmation, creatorid)
VALUES ('nothing', '2', 'Second', '1', '2');

INSERT INTO posts (creatorid, text, groupid, title, viewCount)
VALUES ('1', 'nothing', '1', 'nothing', '0');
INSERT INTO posts (creatorid, text, groupid, title, viewCount)
VALUES ('2', 'nothing', '2', 'nothing', '0');

INSERT INTO reports (creatorid, status, text, helperid, title)
VALUES ('1', 'WAITED', 'nothing', '2', 'nothing');
INSERT INTO reports (creatorid, status, text, helperid, title)
VALUES ('2', 'WAITED', 'nothing', '3', 'nothing');

INSERT INTO tracklist (albumid, trackid)
VALUES ('1', '1');
NSERT INTO tracklist (albumid, trackid)
VALUES ('1', '2');
NSERT INTO tracklist (albumid, trackid)
VALUES ('2', '3');
NSERT INTO tracklist (albumid, trackid)
VALUES ('2', '4');

INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'Coconuts - Silver Lights', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'Eirik Suhrke - A New Morning', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'El Huervo - Crush', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'El Huervo - Daisuke', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'El Huervo - Turf', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'Jasper Byrne - Hotline', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'Jasper Byrne - Miami', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'M_O_O_N - Crystals', 1, 1);
INSERT INTO tracks (playsCount, date, name, creatorid, genreid)
VALUES ('0', DATE '2020-12-20', 'M_O_O_N - Hydrogen', 1, 1);



INSERT INTO users (name, confirmation, login, password, role)
VALUES ('Dima', '2', 'dima', '123456', 'ADMIN');
INSERT INTO users (name, confirmation, login, password, role)
VALUES ('Alexey', 1, 'alexey', '123456', 'ADMIN');
INSERT INTO users (name, confirmation, login, password, role)
VALUES ('Pasha', 1, 'pasha', '123456', 'ADMIN');
