USE OutLoud;

CREATE TABLE tracklist (
	albumid INT NULL,
	trackid INT NULL
);