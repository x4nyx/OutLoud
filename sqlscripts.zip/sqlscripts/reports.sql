USE OutLoud;

CREATE TABLE reports (
    id int NOT NULL AUTO_INCREMENT,
    creatorid int NULL,
    status nchar(20) NULL,
    text text NULL,
    helperid int NULL,
    title text NULL,
    PRIMARY KEY (id)
);
