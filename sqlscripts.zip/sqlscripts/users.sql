USE OutLoud;

CREATE TABLE users (
	id int NOT NULL AUTO_INCREMENT,
	name varchar(30) DEFAULT NULL,
	confirmation INT(1) DEFAULT NULL,
	login varchar(30) DEFAULT NULL,
	password varchar(24) DEFAULT NULL,
	role varchar(24) DEFAULT NULL,
	PRIMARY KEY (id)
);