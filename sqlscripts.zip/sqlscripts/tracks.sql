USE OutLoud;

CREATE TABLE tracks(
	id int NOT NULL AUTO_INCREMENT,
	playsCount int NULL,
	date date NULL,
	name nchar(30) NULL,
	creatorid int NULL,
	genreid int NULL,
	PRIMARY KEY (id)
);